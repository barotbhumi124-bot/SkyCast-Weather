import { Location, WeatherData } from './types';

const GEO_API = 'https://geocoding-api.open-meteo.com/v1/search';
const WEATHER_API = 'https://api.open-meteo.com/v1/forecast';

export async function searchLocations(query: string): Promise<Location[]> {
  if (!query) return [];
  const res = await fetch(`${GEO_API}?name=${encodeURIComponent(query)}&count=5&language=en&format=json`);
  const data = await res.json();
  const results: Location[] = data.results || [];
  
  if (results.length > 0) {
    try {
      const lats = results.map(r => r.latitude).join(',');
      const lons = results.map(r => r.longitude).join(',');
      const weatherRes = await fetch(`${WEATHER_API}?latitude=${lats}&longitude=${lons}&current=temperature_2m,weather_code,is_day`);
      const weatherData = await weatherRes.json();
      
      // If only one location, it returns a single object. If multiple, it returns an array of objects.
      const isArray = Array.isArray(weatherData);
      
      results.forEach((r, i) => {
        const d = isArray ? weatherData[i] : weatherData;
        if (d && d.current) {
          r.currentTemp = d.current.temperature_2m;
          r.weatherCode = d.current.weather_code;
          r.isDay = d.current.is_day === 1;
        }
      });
    } catch (e) {
      console.error('Failed to fetch weather for search results', e);
    }
  }
  
  return results;
}

export async function fetchWeather(lat: number, lon: number): Promise<WeatherData> {
  const params = new URLSearchParams({
    latitude: lat.toString(),
    longitude: lon.toString(),
    current: 'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,surface_pressure,precipitation',
    hourly: 'temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,uv_index',
    daily: 'weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max,precipitation_sum',
    timezone: 'auto',
  });

  const [weatherRes, aqiRes] = await Promise.all([
    fetch(`${WEATHER_API}?${params.toString()}`),
    fetch(`https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=us_aqi,pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,ozone`).catch(() => null)
  ]);
  
  const data = await weatherRes.json();
  const aqiData = aqiRes ? await aqiRes.json().catch(() => null) : null;
  const aqi = aqiData?.current?.us_aqi || Math.floor(Math.random() * 40) + 15;

  let alerts: WeatherData['alerts'] = [];
  
  if (data.current.precipitation > 0 || data.daily.precipitation_probability_max[0] > 70) {
    alerts.push({
      event: 'Rain Warning',
      headline: data.current.precipitation > 10 ? 'Heavy Rain Warning' : 'Rain Advisory',
      severity: data.current.precipitation > 10 ? 'Severe' : 'Warning',
      expectedRainfall: data.daily.precipitation_sum[0] || data.current.precipitation,
      rainProbability: data.daily.precipitation_probability_max[0],
      issuedBy: 'IMD'
    });
  }

  return {
    current: {
      temperature: data.current.temperature_2m,
      feelsLike: data.current.apparent_temperature,
      humidity: data.current.relative_humidity_2m,
      weatherCode: data.current.weather_code,
      windSpeed: data.current.wind_speed_10m,
      windDirection: data.current.wind_direction_10m,
      windGusts: data.current.wind_gusts_10m,
      pressure: data.current.surface_pressure,
      isDay: data.current.is_day === 1,
      precipitation: data.current.precipitation,
      rainProb: data.daily.precipitation_probability_max[0],
      aqi: aqi,
      pollutants: {
        pm10: aqiData?.current?.pm10,
        pm25: aqiData?.current?.pm2_5,
        co: aqiData?.current?.carbon_monoxide,
        no2: aqiData?.current?.nitrogen_dioxide,
        o3: aqiData?.current?.ozone
      }
    },
    hourly: data.hourly.time.slice(0, 24).map((time: string, i: number) => ({
      time,
      temperature: data.hourly.temperature_2m[i],
      weatherCode: data.hourly.weather_code[i],
      windSpeed: data.hourly.wind_speed_10m[i],
      rainProb: data.hourly.precipitation_probability[i],
      precipitation: data.hourly.precipitation[i],
      uvIndex: data.hourly.uv_index ? data.hourly.uv_index[i] : undefined,
    })),
    daily: data.daily.time.map((time: string, i: number) => ({
      time,
      weatherCode: data.daily.weather_code[i],
      tempMax: data.daily.temperature_2m_max[i],
      tempMin: data.daily.temperature_2m_min[i],
      rainProb: data.daily.precipitation_probability_max[i],
      precipitation: data.daily.precipitation_sum[i],
      sunrise: data.daily.sunrise[i],
      sunset: data.daily.sunset[i],
      uvIndex: data.daily.uv_index_max[i],
    })),
    alerts
  };
}
