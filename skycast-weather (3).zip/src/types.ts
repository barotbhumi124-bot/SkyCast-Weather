export interface Location {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  country: string;
  admin1?: string;
  currentTemp?: number;
  weatherCode?: number;
  isDay?: boolean;
}

export interface WeatherAlert {
  event: string;
  headline: string;
  severity: 'Severe' | 'Warning' | 'Watch' | 'Advisory';
  expectedRainfall?: number;
  rainProbability?: number;
  issuedBy?: string;
}

export interface WeatherData {
  current: {
    temperature: number;
    feelsLike: number;
    humidity: number;
    weatherCode: number;
    windSpeed: number;
    windDirection: number;
    windGusts: number;
    pressure: number;
    isDay: boolean;
    precipitation?: number;
    rainProb?: number;
    aqi?: number;
    pollutants?: {
      pm10?: number;
      pm25?: number;
      co?: number;
      no2?: number;
      o3?: number;
    };
  };
  hourly: Array<{
    time: string;
    temperature: number;
    weatherCode: number;
    windSpeed: number;
    rainProb: number;
    precipitation?: number;
    uvIndex?: number;
  }>;
  daily: Array<{
    time: string;
    weatherCode: number;
    tempMax: number;
    tempMin: number;
    rainProb: number;
    precipitation?: number;
    sunrise: string;
    sunset: string;
    uvIndex: number;
  }>;
  alerts?: WeatherAlert[];
}
