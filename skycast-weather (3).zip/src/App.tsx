import React, { useState, useEffect } from 'react';
import { BackgroundVideo } from './components/BackgroundVideo';
import { CurrentWeather } from './components/CurrentWeather';
import { HourlyForecast } from './components/HourlyForecast';
import { DailyForecast } from './components/DailyForecast';
import { WeatherAlerts } from './components/WeatherAlerts';
import { SunTimes } from './components/SunTimes';
import { MoonPhase } from './components/MoonPhase';
import { AirQuality } from './components/AirQuality';
import { WeatherRadar } from './components/WeatherRadar';
import { UvIndex } from './components/UvIndex';
import { AiInsights } from './components/AiInsights';
import { WeatherFact } from './components/WeatherFact';
import { Location, WeatherData } from './types';
import { fetchWeather } from './api';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, Heart, RefreshCw, ChevronLeft, ChevronRight, Home, Map as MapIcon, Settings as SettingsIcon, MapPin, Share2 } from 'lucide-react';
import { SettingsView } from './components/SettingsView';
import { LocationsView } from './components/LocationsView';
import { GujaratWeather } from './components/GujaratWeather';
import { useAuth } from './lib/AuthContext.tsx';

const DEFAULT_LOCATION: Location = {
  id: 1253573,
  name: "Vadodara",
  latitude: 22.3072,
  longitude: 73.1812,
  country: "India",
  admin1: "Gujarat"
};

const FAVORITES_KEY = 'weathernow_favorites';
const TEMP_UNIT_KEY = 'weathernow_temp_unit';
const ALERTS_ENABLED_KEY = 'weathernow_alerts_enabled';
const PUSH_NOTIFICATIONS_KEY = 'weathernow_push_notifications';
const THEME_KEY = 'weathernow_theme';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'search' | 'settings'>('home');
  const [favorites, setFavorites] = useState<Location[]>([]);
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [location, setLocation] = useState<Location>(DEFAULT_LOCATION);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isFahrenheit, setIsFahrenheit] = useState(false);
  const [alertsEnabled, setAlertsEnabled] = useState(true);
  const [theme, setTheme] = useState<'adaptive' | 'dark' | 'light'>('adaptive');
  const [showToast, setShowToast] = useState(false);
  const [pushNotificationsEnabled, setPushNotificationsEnabled] = useState(true);
  const { user, getToken } = useAuth();

  // Swipe gesture states
  const [touchStart, setTouchStart] = useState<{ x: number, y: number } | null>(null);
  const [touchEnd, setTouchEnd] = useState<{ x: number, y: number } | null>(null);
  const [refreshProgress, setRefreshProgress] = useState(0);

  const fetchFavorites = async () => {
    if (user) {
      try {
        const token = await getToken();
        const res = await fetch('/api/favorites', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        if (res.ok) {
          const data = await res.json();
          if (data && data.length > 0) {
            const parsedFavorites = data.map((d: any) => ({
              id: d.id,
              name: d.locationName,
              latitude: d.latitude,
              longitude: d.longitude,
              country: d.country,
              admin1: d.admin1,
            }));
            setFavorites(parsedFavorites);
            return parsedFavorites;
          }
        }
      } catch (err) {
        console.error("Failed to fetch remote favorites", err);
      }
    }
    
    // Fallback to local storage if not logged in or fetch fails
    const saved = localStorage.getItem(FAVORITES_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0) {
          setFavorites(parsed);
          return parsed;
        }
      } catch (e) {
        console.error('Failed to parse favorites', e);
      }
    }
    
    setFavorites([DEFAULT_LOCATION]);
    return [DEFAULT_LOCATION];
  };

  useEffect(() => {
    const initApp = async () => {
      const savedUnit = localStorage.getItem(TEMP_UNIT_KEY);
      if (savedUnit === 'F') setIsFahrenheit(true);
      
      const savedAlerts = localStorage.getItem(ALERTS_ENABLED_KEY);
      if (savedAlerts === 'false') setAlertsEnabled(false);

      const savedPush = localStorage.getItem(PUSH_NOTIFICATIONS_KEY);
      if (savedPush === 'false') setPushNotificationsEnabled(false);
      
      const savedTheme = localStorage.getItem(THEME_KEY) as 'adaptive' | 'dark' | 'light';
      if (savedTheme) setTheme(savedTheme);
      
      const favs = await fetchFavorites();
      if (favs.length > 0 && !weather) {
        loadWeather(favs[0]);
      }
    };
    
    initApp();
  }, [user]);

  const checkAndSendNotifications = (data: WeatherData, loc: Location, pushEnabled: boolean, useFahrenheit: boolean) => {
    if (!pushEnabled) return;
    if (Notification.permission !== 'granted') return;

    // To prevent spamming, we could use localStorage to track last notification time,
    // but for this implementation we will just send an alert if it's morning or there's an alert.
    const lastAlertTime = localStorage.getItem('weathernow_last_notif');
    const now = Date.now();
    // Only send once per hour max
    if (lastAlertTime && now - parseInt(lastAlertTime) < 3600000) return;

    const currentHour = new Date().getHours();
    let sent = false;
    
    if (data.alerts && data.alerts.length > 0) {
      const alertStr = data.alerts[0].event;
      new Notification(`Extreme Weather Alert: ${loc.name}`, {
        body: `Warning: ${alertStr}. Please stay safe.`,
      });
      sent = true;
    } else if (currentHour >= 6 && currentHour <= 10) {
      const temp = useFahrenheit ? Math.round(data.current.temperature * 9 / 5 + 32) : Math.round(data.current.temperature);
      new Notification(`Morning Summary: ${loc.name}`, {
        body: `It's ${temp}°${useFahrenheit ? 'F' : 'C'} today. Have a great day!`,
      });
      sent = true;
    }

    if (sent) {
      localStorage.setItem('weathernow_last_notif', now.toString());
    }
  };

  const loadWeather = async (loc: Location) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchWeather(loc.latitude, loc.longitude);
      setWeather(data);
      setLocation(loc);
      
      // Update current index if the location is in favorites
      setFavorites(prevFavs => {
        const idx = prevFavs.findIndex(f => f.id === loc.id);
        setCurrentIndex(idx);
        return prevFavs;
      });

      // Pass the current state values directly, as state might not have updated yet if we changed it just before calling
      checkAndSendNotifications(data, loc, localStorage.getItem(PUSH_NOTIFICATIONS_KEY) === 'true', localStorage.getItem(TEMP_UNIT_KEY) === 'F');

    } catch (err) {
      setError("Failed to fetch weather data. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleTogglePushNotifications = async () => {
    if (pushNotificationsEnabled) {
      setPushNotificationsEnabled(false);
      localStorage.setItem(PUSH_NOTIFICATIONS_KEY, 'false');
      return;
    }

    if (!('Notification' in window)) {
      alert('This browser does not support desktop notifications.');
      return;
    }

    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      setPushNotificationsEnabled(true);
      localStorage.setItem(PUSH_NOTIFICATIONS_KEY, 'true');
      
      new Notification('Weather Notifications Enabled', {
        body: 'You will now receive daily morning summaries and extreme weather alerts.',
      });
    } else {
      alert('Notification permission denied.');
    }
  };

  const handleGeolocate = () => {
    setIsLocating(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const loc: Location = {
            id: Date.now(), // Generate a unique ID for current location
            name: "Current Location",
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            country: ""
          };
          await loadWeather(loc);
          setIsLocating(false);
        },
        (err) => {
          setError("Location access denied or unavailable.");
          setIsLocating(false);
        }
      );
    } else {
      setError("Geolocation is not supported by your browser.");
      setIsLocating(false);
    }
  };

  const toggleFavorite = async () => {
    const isFavorite = currentIndex !== -1;
    let newFavs;
    if (isFavorite) {
      newFavs = favorites.filter(f => f.id !== location.id);
      if (newFavs.length === 0) {
        newFavs = [DEFAULT_LOCATION]; // Ensure at least one favorite exists
      }
      if (user) {
        try {
          const token = await getToken();
          await fetch(`/api/favorites/${location.id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
          });
        } catch (e) {
          console.error("Failed to delete favorite on server", e);
        }
      }
    } else {
      newFavs = [...favorites, location];
      if (user) {
        try {
          const token = await getToken();
          const res = await fetch('/api/favorites', {
            method: 'POST',
            headers: { 
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              locationName: location.name,
              latitude: location.latitude,
              longitude: location.longitude,
              country: location.country,
              admin1: location.admin1
            })
          });
          if (res.ok) {
            const added = await res.json();
            // Update location id to match database id
            newFavs = newFavs.map(f => f.id === location.id ? { ...f, id: added.id } : f);
            setLocation({ ...location, id: added.id });
          }
        } catch (e) {
          console.error("Failed to add favorite on server", e);
        }
      }
    }
    setFavorites(newFavs);
    if (!user) localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavs));
    setCurrentIndex(newFavs.findIndex(f => f.id === (isFavorite ? location.id : newFavs[newFavs.length - 1].id)));
  };

  const removeFavorite = async (id: number) => {
    let newFavs = favorites.filter(f => f.id !== id);
    if (newFavs.length === 0) {
      newFavs = [DEFAULT_LOCATION];
    }
    if (user) {
      try {
        const token = await getToken();
        await fetch(`/api/favorites/${id}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        });
      } catch (e) {
        console.error("Failed to delete favorite on server", e);
      }
    }
    
    setFavorites(newFavs);
    if (!user) localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavs));
    
    if (location.id === id) {
      loadWeather(newFavs[0]);
    } else {
      setCurrentIndex(newFavs.findIndex(f => f.id === location.id));
    }
  };

  const shareWeather = () => {
    if (!weather) return;
    const temp = isFahrenheit ? Math.round(weather.current.temperature * 9 / 5 + 32) : Math.round(weather.current.temperature);
    const text = `Current weather in ${location.name}: \n🌡️ ${temp}°${isFahrenheit ? 'F' : 'C'}\n💨 Wind: ${weather.current.windSpeed} km/h\nPowered by WeatherNow`;
    navigator.clipboard.writeText(text);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart({ x: e.targetTouches[0].clientX, y: e.targetTouches[0].clientY });
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (!touchStart) return;
    const currentY = e.targetTouches[0].clientY;
    const currentX = e.targetTouches[0].clientX;
    setTouchEnd({ x: currentX, y: currentY });

    const distanceY = currentY - touchStart.y;
    const distanceX = currentX - touchStart.x;
    const target = e.currentTarget as HTMLElement;

    if (target.scrollTop === 0 && distanceY > 0 && Math.abs(distanceY) > Math.abs(distanceX)) {
      setRefreshProgress(Math.min(distanceY * 0.4, 60)); // Max 60px pull down visual
    }
  };

  const onTouchEnd = async () => {
    if (!touchStart || !touchEnd) {
      setRefreshProgress(0);
      return;
    }
    const distanceX = touchStart.x - touchEnd.x;
    const distanceY = touchStart.y - touchEnd.y;
    
    // Configurable thresholds for swipe detection
    const horizontalThreshold = 50;
    const verticalThreshold = 50;

    const isLeftSwipe = distanceX > horizontalThreshold;
    const isRightSwipe = distanceX < -horizontalThreshold;
    const isDownSwipe = distanceY < -verticalThreshold;

    if (Math.abs(distanceX) > Math.abs(distanceY)) {
      // Horizontal swipe to change cities
      if (activeTab === 'home') {
        if (isLeftSwipe && currentIndex !== -1 && currentIndex < favorites.length - 1) {
          await loadWeather(favorites[currentIndex + 1]);
        } else if (isRightSwipe && currentIndex > 0) {
          await loadWeather(favorites[currentIndex - 1]);
        }
      }
    } else {
      // Vertical pull-to-refresh
      if (activeTab === 'home' && isDownSwipe && refreshProgress >= 40) {
        await loadWeather(location);
      }
    }
    setRefreshProgress(0);
    setTouchStart(null);
    setTouchEnd(null);
  };

  const isFavorite = currentIndex !== -1;

  return (
    <div className="min-h-screen bg-gray-900 transition-colors duration-500 flex items-center justify-center sm:py-8 font-sans overscroll-y-none">
      <div className="relative w-full max-w-[420px] h-[100dvh] sm:h-[850px] bg-black sm:rounded-[48px] shadow-2xl overflow-hidden sm:border-[8px] border-gray-800 transition-colors duration-500 flex flex-col">
        <BackgroundVideo weatherCode={weather?.current.weatherCode} isDay={weather?.current.isDay} />

        <main 
          className="relative z-10 flex-1 flex flex-col h-full overflow-y-auto no-scrollbar scroll-smooth overscroll-y-none touch-pan-y"
          onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
          {activeTab === 'home' && (
            <>
              {/* Pull to refresh indicator */}
              <div 
                className="absolute left-0 right-0 flex justify-center items-center pointer-events-none transition-transform duration-150 ease-out z-50"
                style={{ transform: `translateY(${refreshProgress > 0 ? refreshProgress : -50}px)` }}
              >
                <div className="bg-white/20 backdrop-blur-xl rounded-full p-2.5 shadow-lg border border-white/30">
                  <RefreshCw className={`w-5 h-5 text-white ${refreshProgress > 50 ? 'animate-spin' : ''}`} style={{ transform: refreshProgress <= 50 ? `rotate(${refreshProgress * 5}deg)` : 'none' }} />
                </div>
              </div>

              <header className="px-5 pt-12 pb-4 sticky top-0 z-40 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-white/70" />
                  <span className="text-white font-medium text-[20px] tracking-tight truncate max-w-[200px]">{location.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={shareWeather}
                    className="p-3 bg-black/25 backdrop-blur-xl border border-white/10 rounded-full shadow-lg transition-transform active:scale-95 shrink-0"
                    aria-label="Share weather"
                  >
                    <Share2 className="w-5 h-5 text-white/70" />
                  </button>
                  <button 
                    onClick={toggleFavorite}
                    className="p-3 bg-black/25 backdrop-blur-xl border border-white/10 rounded-full shadow-lg transition-transform active:scale-95 shrink-0"
                    aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
                  >
                    <Heart className={`w-5 h-5 ${isFavorite ? 'fill-red-500 text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.6)]' : 'text-white/70'}`} />
                  </button>
                </div>
              </header>

              <div className="px-5 pb-28 flex-1 flex flex-col relative">
                
                {/* Pagination dots for favorites */}
                {favorites.length > 1 && currentIndex !== -1 && (
                  <div className="flex justify-center items-center gap-2 mb-2">
                    <ChevronLeft className={`w-4 h-4 ${currentIndex > 0 ? 'text-white/70' : 'text-white/20'}`} />
                    {favorites.map((_, idx) => (
                      <div key={idx} className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${idx === currentIndex ? 'bg-white w-4' : 'bg-white/30'}`} />
                    ))}
                    <ChevronRight className={`w-4 h-4 ${currentIndex < favorites.length - 1 ? 'text-white/70' : 'text-white/20'}`} />
                  </div>
                )}

                <AnimatePresence mode="wait">
                  {loading ? (
                    <motion.div 
                      key="loading"
                      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                      className="flex-1 flex flex-col items-center justify-center min-h-[400px]"
                    >
                      <div className="w-10 h-10 border-4 border-white/20 border-t-white rounded-full animate-spin mb-4" />
                      <p className="text-white/80 font-medium">Loading forecast...</p>
                    </motion.div>
                  ) : error ? (
                    <motion.div 
                      key="error"
                      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                      className="flex-1 flex flex-col items-center justify-center min-h-[400px] text-white text-center px-4"
                    >
                      <ShieldAlert className="w-16 h-16 mb-4 text-red-400" />
                      <p className="font-medium text-lg mb-2">Oops!</p>
                      <p className="text-white/70">{error}</p>
                      <button 
                        onClick={() => loadWeather(DEFAULT_LOCATION)}
                        className="mt-6 px-6 py-2 bg-white/20 rounded-full hover:bg-white/30 transition-colors backdrop-blur-md"
                      >
                        Try Again
                      </button>
                    </motion.div>
                  ) : weather ? (
                    <motion.div 
                      key={`content-${location.id}`}
                      initial={{ opacity: 0, x: touchStart ? (touchStart.x > (touchEnd?.x || touchStart.x) ? 50 : -50) : 0, scale: 0.98 }} 
                      animate={{ opacity: 1, x: 0, scale: 1 }} 
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                      className="flex flex-col gap-4"
                    >
                      <CurrentWeather weather={weather} location={location} isFahrenheit={isFahrenheit} />
                      {alertsEnabled && <WeatherAlerts alerts={weather.alerts} />}
                      <AiInsights weather={weather} location={location} />
                      <WeatherFact />
                      <HourlyForecast hourly={weather.hourly} isFahrenheit={isFahrenheit} />
                      <AirQuality aqi={weather.current.aqi} pollutants={weather.current.pollutants} />
                      <WeatherRadar location={location} hourly={weather.hourly} />
                      <div className="grid grid-cols-2 gap-4">
                        <SunTimes sunrise={weather.daily[0]?.sunrise} sunset={weather.daily[0]?.sunset} />
                        <MoonPhase />
                      </div>
                      <UvIndex hourly={weather.hourly} />
                      <GujaratWeather isFahrenheit={isFahrenheit} />
                      <DailyForecast daily={weather.daily} isFahrenheit={isFahrenheit} />
                    </motion.div>
                  ) : null}
                </AnimatePresence>
              </div>
            </>
          )}

          {activeTab === 'search' && (
            <LocationsView
              favorites={favorites}
              onSelect={(loc) => { loadWeather(loc); setActiveTab('home'); }}
              onGeolocate={() => { handleGeolocate(); setActiveTab('home'); }}
              isLocating={isLocating}
              onRemoveFavorite={removeFavorite}
              currentLocationId={location.id}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              isFahrenheit={isFahrenheit}
              setIsFahrenheit={(v) => { setIsFahrenheit(v); localStorage.setItem(TEMP_UNIT_KEY, v ? 'F' : 'C'); }}
              alertsEnabled={alertsEnabled}
              setAlertsEnabled={(v) => { setAlertsEnabled(v); localStorage.setItem(ALERTS_ENABLED_KEY, v.toString()); }}
              theme={theme}
              setTheme={(v) => { setTheme(v); localStorage.setItem(THEME_KEY, v); }}
              pushNotificationsEnabled={pushNotificationsEnabled}
              onTogglePushNotifications={handleTogglePushNotifications}
            />
          )}
        </main>

        {/* Toast Notification */}
        <AnimatePresence>
          {showToast && (
            <motion.div 
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.9 }}
              className="absolute bottom-28 left-1/2 -translate-x-1/2 z-50 bg-white/20 backdrop-blur-xl border border-white/30 text-white px-5 py-2.5 rounded-full shadow-[0_4px_20px_rgba(0,0,0,0.5)] flex items-center gap-2 font-medium text-sm tracking-wide"
            >
              <Share2 className="w-4 h-4 text-blue-400" />
              Copied to clipboard
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom Navigation */}
        <nav className="absolute bottom-0 left-0 right-0 bg-black/40 backdrop-blur-2xl border-t border-white/10 px-10 py-5 flex justify-around items-center z-50 sm:rounded-b-[40px]">
          <button onClick={() => setActiveTab('home')} className={`flex flex-col items-center gap-1.5 transition-colors ${activeTab === 'home' ? 'text-white' : 'text-white/40 hover:text-white/70'}`}>

            <Home className="w-6 h-6" />
            <span className="text-[10px] font-semibold tracking-wide uppercase">Home</span>
          </button>
          <button onClick={() => setActiveTab('search')} className={`flex flex-col items-center gap-1.5 transition-colors ${activeTab === 'search' ? 'text-white' : 'text-white/40 hover:text-white/70'}`}>
            <MapIcon className="w-6 h-6" />
            <span className="text-[10px] font-semibold tracking-wide uppercase">Search</span>
          </button>
          <button onClick={() => setActiveTab('settings')} className={`flex flex-col items-center gap-1.5 transition-colors ${activeTab === 'settings' ? 'text-white' : 'text-white/40 hover:text-white/70'}`}>
            <SettingsIcon className="w-6 h-6" />
            <span className="text-[10px] font-semibold tracking-wide uppercase">Settings</span>
          </button>
        </nav>
      </div>
    </div>
  );
}

