// src/db/users.ts
import { db } from './index.ts';
import { users } from './schema.ts';

export async function getOrCreateUser(uid: string, email: string, name: string, avatarUrl: string) {
  try {
    const result = await db.insert(users)
      .values({
        uid,
        email,
        name,
        avatarUrl,
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email,
          name,
          avatarUrl,
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error("Database query failed in getOrCreateUser:", error);
    // Don't throw to prevent auth flow from breaking if DB fails temporarily
    return null; 
  }
}
