import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export function BackgroundVideo({ weatherCode, isDay }: { weatherCode?: number, isDay?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const isRain = weatherCode && [61, 63, 65, 66, 67, 80, 81, 82].includes(weatherCode);
  const isDrizzle = weatherCode && [51, 53, 55, 56, 57].includes(weatherCode);
  const isSnow = weatherCode && [71, 73, 75, 77, 85, 86].includes(weatherCode);
  const isThunderstorm = weatherCode && [95, 96, 99].includes(weatherCode);
  const isFog = weatherCode && [45, 48].includes(weatherCode);
  const isCloudy = weatherCode && [3].includes(weatherCode);
  const isPartlyCloudy = weatherCode === 2;
  const isClear = weatherCode === 0 || weatherCode === 1;

  const getVideoForWeather = () => {
    if (weatherCode === undefined) return 'https://cdn.pixabay.com/video/2016/09/13/5193-181165502_large.mp4';
    
    if (!isDay) return 'https://cdn.pixabay.com/video/2021/03/17/68222-525946401_large.mp4'; // Starry night

    if (isThunderstorm) return 'https://cdn.pixabay.com/video/2021/07/26/82772-581335759_large.mp4';
    if (isRain) return 'https://cdn.pixabay.com/video/2019/06/25/24711-344485596_large.mp4'; 
    if (isDrizzle) return 'https://cdn.pixabay.com/video/2023/07/25/173167-848831952_large.mp4';
    if (isSnow) return 'https://cdn.pixabay.com/video/2020/02/24/32822-393278556_large.mp4';
    if (isFog) return 'https://cdn.pixabay.com/video/2015/09/25/717-139366551_large.mp4';
    if (isCloudy) return 'https://cdn.pixabay.com/video/2021/08/11/84683-587289895_large.mp4';
    if (isPartlyCloudy) return 'https://cdn.pixabay.com/video/2019/08/07/25075-348612140_large.mp4';
    
    return 'https://cdn.pixabay.com/video/2016/09/13/5193-181165502_large.mp4'; // Sunny
  };

  const videoSrc = getVideoForWeather();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: any[] = [];
    
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    window.addEventListener('resize', resize);
    resize();

    // Initialize particles
    if (isRain || isThunderstorm || isDrizzle) {
      const pCount = isDrizzle ? 50 : isThunderstorm ? 250 : 150;
      for (let i = 0; i < pCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          length: Math.random() * (isDrizzle ? 15 : 30) + 10,
          speed: Math.random() * (isDrizzle ? 10 : 20) + (isDrizzle ? 10 : 20),
          opacity: Math.random() * 0.5 + 0.2
        });
      }
    } else if (isSnow) {
      for (let i = 0; i < 150; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          radius: Math.random() * 3 + 1,
          speedX: Math.random() * 2 - 1,
          speedY: Math.random() * 2 + 1,
          opacity: Math.random() * 0.5 + 0.3
        });
      }
    } else if (isCloudy || isPartlyCloudy) {
      for (let i = 0; i < 10; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * (canvas.height / 2),
          radius: Math.random() * 100 + 50,
          speedX: Math.random() * 0.5 + 0.1,
          opacity: Math.random() * 0.3 + 0.1
        });
      }
    }

    let lightningTimer = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (isRain || isThunderstorm || isDrizzle) {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        particles.forEach(p => {
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + p.length * 0.1, p.y + p.length);
          p.y += p.speed;
          p.x += p.speed * 0.1;
          if (p.y > canvas.height) {
            p.y = -p.length;
            p.x = Math.random() * canvas.width;
          }
        });
        ctx.stroke();

        if (isThunderstorm) {
          lightningTimer++;
          if (lightningTimer > Math.random() * 200 + 100) {
            ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            lightningTimer = 0;
          }
        }
      } else if (isSnow) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.beginPath();
        particles.forEach(p => {
          ctx.moveTo(p.x, p.y);
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          p.y += p.speedY;
          p.x += p.speedX;
          if (p.y > canvas.height) {
            p.y = -10;
            p.x = Math.random() * canvas.width;
          }
        });
        ctx.fill();
      } else if (isCloudy || isPartlyCloudy) {
        particles.forEach(p => {
          ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.arc(p.x + p.radius * 0.5, p.y - p.radius * 0.3, p.radius * 0.8, 0, Math.PI * 2);
          ctx.arc(p.x + p.radius, p.y, p.radius * 0.9, 0, Math.PI * 2);
          ctx.fill();
          
          p.x += p.speedX;
          if (p.x > canvas.width + p.radius * 2) {
            p.x = -p.radius * 2;
            p.y = Math.random() * (canvas.height / 2);
          }
        });
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [isRain, isSnow, isThunderstorm, isDrizzle, isCloudy, isPartlyCloudy]);

  return (
    <div className="absolute inset-0 z-0 overflow-hidden bg-slate-900 pointer-events-none">
      <AnimatePresence>
        <motion.video
          key={videoSrc}
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.8 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5 }}
          autoPlay
          loop
          muted
          playsInline
          className="absolute min-w-full min-h-full object-cover"
          src={videoSrc}
        />
      </AnimatePresence>
      
      {/* Dynamic Overlay based on weather */}
      {isFog && (
        <motion.div 
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute inset-0 bg-white/40 backdrop-blur-md" 
        />
      )}
      
      {isDay && isClear && (
        <motion.div 
          animate={{ scale: [1, 1.1, 1], opacity: [0.2, 0.3, 0.2] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-yellow-400 rounded-full blur-[100px]" 
        />
      )}

      {/* Weather particles overlay */}
      <canvas ref={canvasRef} className="absolute inset-0 z-10 pointer-events-none" />

      {/* Base gradient overlays for text contrast */}
      <div className="absolute inset-0 bg-black/10 z-10" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/80 z-10" />
    </div>
  );
}
