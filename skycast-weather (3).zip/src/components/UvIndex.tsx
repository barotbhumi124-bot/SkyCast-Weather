import React from 'react';
import { Sun } from 'lucide-react';
import { WeatherData } from '../types';

interface Props {
  hourly: WeatherData['hourly'];
}

export function UvIndex({ hourly }: Props) {
  // Extract UV data for the next 12 hours
  const uvData = hourly.slice(0, 12).map(h => Math.max(0, h.uvIndex || 0)); 
  
  // Create mock UV data based on time of day if API doesn't provide it
  const currentHour = new Date().getHours();
  const mockUvData = Array.from({ length: 12 }).map((_, i) => {
    const h = (currentHour + i) % 24;
    // UV is highest around 12-14 (noon), zero at night
    if (h < 6 || h > 19) return 0;
    const peak = 13;
    const distance = Math.abs(h - peak);
    return Math.max(0, 10 - distance * 1.5);
  });
  
  const dataToUse = uvData.some(v => v > 0) ? uvData : mockUvData;
  const currentUv = dataToUse[0];
  
  const getUvLevel = (uv: number) => {
    if (uv <= 2) return { text: 'Low', color: 'text-green-400' };
    if (uv <= 5) return { text: 'Moderate', color: 'text-yellow-400' };
    if (uv <= 7) return { text: 'High', color: 'text-orange-400' };
    if (uv <= 10) return { text: 'Very High', color: 'text-red-400' };
    return { text: 'Extreme', color: 'text-purple-400' };
  };
  
  const maxUv = Math.max(...dataToUse, 10);
  
  return (
    <div className="glass-panel rounded-[32px] p-5 h-full flex flex-col">
      <div className="flex items-center gap-2 text-white/70 mb-2 px-1">
        <Sun className="w-4 h-4" />
        <span className="text-[13px] font-medium uppercase tracking-wider">UV Index</span>
      </div>
      
      <div className="flex-1 flex flex-col justify-between px-1">
        <div className="mb-2 mt-1">
          <div className="text-3xl font-semibold text-white tracking-tight">{currentUv.toFixed(1)}</div>
          <div className={`text-[15px] font-medium ${getUvLevel(currentUv).color}`}>
            {getUvLevel(currentUv).text}
          </div>
        </div>
        
        {/* Simple bar chart for trend */}
        <div className="flex items-end justify-between h-12 gap-1 mt-auto border-b border-white/10 pb-2">
          {dataToUse.map((val, i) => (
            <div key={i} className="w-full flex justify-center h-full items-end group relative">
              <div 
                className={`w-full rounded-full transition-all duration-300 ${i === 0 ? 'bg-white' : 'bg-white/20'}`}
                style={{ height: `${Math.max(4, (val / maxUv) * 100)}%` }}
              ></div>
              <div className="absolute -top-6 opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 text-white text-[10px] py-0.5 px-1.5 rounded whitespace-nowrap z-10 pointer-events-none backdrop-blur-md">
                {val.toFixed(1)}
              </div>
            </div>
          ))}
        </div>
        <div className="text-white/40 text-[10px] font-medium uppercase tracking-wider mt-2">12-Hour Trend</div>
      </div>
    </div>
  );
}
