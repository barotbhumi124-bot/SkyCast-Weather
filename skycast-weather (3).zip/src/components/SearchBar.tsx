import React, { useState, useEffect } from 'react';
import { Search, MapPin, Loader2, X, Clock, Mic, TrendingUp } from 'lucide-react';
import { searchLocations } from '../api';
import { Location } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { getWeatherIcon, formatTemp, getWeatherDescription } from '../utils';

interface Props {
  onSelect: (loc: Location) => void;
  onGeolocate: () => void;
  isLocating: boolean;
}

const RECENT_SEARCHES_KEY = 'weathernow_recent_searches';
const TEMP_UNIT_KEY = 'weathernow_temp_unit';

const POPULAR_SEARCHES = [
  "Ahmedabad", "Vadodara", "Surat", "Rajkot", 
  "Jamnagar", "Dwarka", "Mumbai", "Delhi", 
  "Bengaluru", "Chennai", "Hyderabad", "Kolkata"
];

export function SearchBar({ onSelect, onGeolocate, isLocating }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Location[]>([]);
  const [recentSearches, setRecentSearches] = useState<Location[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const isFahrenheit = localStorage.getItem(TEMP_UNIT_KEY) === 'F';

  useEffect(() => {
    const saved = localStorage.getItem(RECENT_SEARCHES_KEY);
    if (saved) {
      try {
        setRecentSearches(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse recent searches', e);
      }
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(async () => {
      if (query.length >= 2 && !isListening) {
        setIsSearching(true);
        try {
          const res = await searchLocations(query);
          setResults(res);
        } catch (e) {
          console.error(e);
        } finally {
          setIsSearching(false);
        }
      } else {
        setResults([]);
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [query, isListening]);

  const handleSelect = (loc: Location) => {
    // Save to recent
    const updatedRecent = [loc, ...recentSearches.filter(r => r.id !== loc.id)].slice(0, 10);
    setRecentSearches(updatedRecent);
    localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updatedRecent));
    
    onSelect(loc);
    setQuery('');
    setIsFocused(false);
  };

  const handleVoiceSearch = () => {
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice search isn't supported in this browser.");
      return;
    }
    
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    
    recognition.onstart = () => {
      setIsListening(true);
      setQuery('Listening...');
    };
    
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setQuery(transcript);
    };
    
    recognition.onerror = (event: any) => {
      console.error('Speech recognition error', event.error);
      if (query === 'Listening...') setQuery('');
      setIsListening(false);
    };
    
    recognition.onend = () => {
      setIsListening(false);
    };
    
    recognition.start();
  };

  const handlePopularClick = async (cityName: string) => {
    setQuery(cityName);
    setIsFocused(true);
    setIsSearching(true);
    try {
      const res = await searchLocations(cityName);
      if (res.length > 0) {
        handleSelect(res[0]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSearching(false);
    }
  };

  const showDropdown = isFocused && (query.length > 0 || recentSearches.length > 0);

  return (
    <div className="relative z-50 w-full mx-auto">
      <div className={`glass-panel flex items-center px-4 py-3 rounded-full transition-all duration-300 ${isFocused ? 'ring-2 ring-blue-400/50 bg-white/20' : ''}`}>
        <Search className={`w-5 h-5 mr-3 shrink-0 transition-colors ${isFocused ? 'text-blue-400' : 'text-white/70'}`} />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setTimeout(() => setIsFocused(false), 200)}
          placeholder="Search global locations, pin code..."
          className="flex-1 bg-transparent border-none outline-none text-white placeholder-white/60 text-[15px]"
        />
        
        {isSearching && <Loader2 className="w-5 h-5 text-blue-400 animate-spin mr-2" />}
        
        {query && !isListening ? (
          <button onClick={() => setQuery('')} className="p-1 text-white/70 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        ) : (
          <button 
            onClick={handleVoiceSearch} 
            className={`p-1 transition-colors mr-1 ${isListening ? 'text-red-400 animate-pulse' : 'text-white/70 hover:text-white'}`}
            title="Voice Search"
          >
            <Mic className="w-5 h-5" />
          </button>
        )}
        
        <div className="w-px h-5 bg-white/20 mx-2"></div>
        
        <button 
          onClick={onGeolocate} 
          disabled={isLocating}
          className="p-1 text-blue-300 hover:text-blue-200 transition-colors shrink-0 flex items-center gap-1"
          title="Use Current Location"
        >
          {isLocating ? <Loader2 className="w-5 h-5 animate-spin" /> : <MapPin className="w-5 h-5" />}
        </button>
      </div>

      <AnimatePresence>
        {showDropdown && (
          <motion.div
            initial={{ opacity: 0, y: -10, filter: 'blur(10px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -10, filter: 'blur(10px)' }}
            className="absolute top-full left-0 right-0 mt-2 glass-panel bg-black/60 backdrop-blur-2xl rounded-[24px] overflow-hidden shadow-2xl border border-white/20 max-h-[60vh] overflow-y-auto no-scrollbar"
          >
            {query.length >= 2 ? (
              <div className="py-2">
                {results.length > 0 ? results.map((loc) => {
                  const WeatherIcon = loc.weatherCode !== undefined ? getWeatherIcon(loc.weatherCode, loc.isDay) : null;
                  
                  return (
                    <button
                      key={loc.id}
                      onClick={() => handleSelect(loc)}
                      className="w-full text-left px-5 py-3 hover:bg-white/10 border-b border-white/5 last:border-0 transition-colors flex items-center justify-between group"
                    >
                      <div className="flex flex-col">
                        <span className="text-white font-medium text-[16px] group-hover:text-blue-300 transition-colors">{loc.name}</span>
                        <span className="text-white/50 text-sm mt-0.5">
                          {loc.admin1 ? `${loc.admin1}, ` : ''}{loc.country}
                        </span>
                      </div>
                      
                      {loc.currentTemp !== undefined && WeatherIcon && (
                        <div className="flex items-center gap-3 bg-white/5 px-3 py-1.5 rounded-xl">
                          <div className="text-right">
                            <div className="text-white font-bold text-[15px]">{formatTemp(loc.currentTemp, isFahrenheit)}°</div>
                            <div className="text-white/40 text-[10px] uppercase font-bold">{getWeatherDescription(loc.weatherCode || 0)}</div>
                          </div>
                          <WeatherIcon className="w-6 h-6 text-blue-300" />
                        </div>
                      )}
                    </button>
                  );
                }) : !isSearching && (
                  <div className="px-5 py-6 text-center text-white/50 text-sm">
                    No locations found for "{query}". Try a different city, district, or pin code.
                  </div>
                )}
              </div>
            ) : (
              <div className="py-4">
                {recentSearches.length > 0 && (
                  <div className="mb-6">
                    <div className="px-5 mb-2 text-[11px] font-bold text-white/40 uppercase tracking-widest flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5" /> Recent Searches
                    </div>
                    <div>
                      {recentSearches.slice(0, 3).map((loc) => (
                        <button
                          key={`recent-${loc.id}`}
                          onClick={() => handleSelect(loc)}
                          className="w-full flex items-center gap-3 px-5 py-2.5 hover:bg-white/10 transition-colors"
                        >
                          <div className="flex flex-col text-left">
                            <span className="text-white font-medium text-[15px]">{loc.name}</span>
                            <span className="text-white/50 text-[12px]">
                              {loc.admin1 ? `${loc.admin1}, ` : ''}{loc.country}
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                
                <div>
                  <div className="px-5 mb-3 text-[11px] font-bold text-white/40 uppercase tracking-widest flex items-center gap-2">
                    <TrendingUp className="w-3.5 h-3.5" /> Popular Destinations
                  </div>
                  <div className="px-5 flex flex-wrap gap-2">
                    {POPULAR_SEARCHES.map((city) => (
                      <button
                        key={city}
                        onMouseDown={(e) => { e.preventDefault(); handlePopularClick(city); }}
                        className="px-3 py-1.5 bg-white/10 hover:bg-blue-500/40 border border-white/10 hover:border-blue-400/50 rounded-full text-white/80 hover:text-white text-[13px] font-medium transition-all"
                      >
                        {city}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
