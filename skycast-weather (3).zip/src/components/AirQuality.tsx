import React from 'react';
import { Wind } from 'lucide-react';
import { motion } from 'motion/react';

export function AirQuality({ aqi = 42, pollutants }: { aqi?: number, pollutants?: any }) {
  let label = 'Good';
  let color = 'bg-green-500';
  let textColor = 'text-green-400';
  let progress = (aqi / 300) * 100;
  let healthRec = 'Air quality is ideal for outdoor activities.';
  if (progress > 100) progress = 100;

  if (aqi > 50) { label = 'Moderate'; color = 'bg-yellow-400'; textColor = 'text-yellow-300'; healthRec = 'Unusually sensitive individuals should consider reducing prolonged outdoor exertion.'; }
  if (aqi > 100) { label = 'Unhealthy (Sens.)'; color = 'bg-orange-500'; textColor = 'text-orange-400'; healthRec = 'Children, active adults, and people with respiratory disease should limit outdoor exertion.'; }
  if (aqi > 150) { label = 'Unhealthy'; color = 'bg-red-500'; textColor = 'text-red-400'; healthRec = 'Active children and adults, and people with respiratory disease should avoid prolonged outdoor exertion.'; }
  if (aqi > 200) { label = 'Very Unhealthy'; color = 'bg-purple-500'; textColor = 'text-purple-400'; healthRec = 'Active children and adults, and people with respiratory disease should avoid all outdoor exertion.'; }
  if (aqi > 300) { label = 'Hazardous'; color = 'bg-rose-700'; textColor = 'text-rose-500'; healthRec = 'Everyone should avoid all outdoor exertion.'; }

  return (
    <div className="glass-panel rounded-[32px] p-5 h-full flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2 text-white/70">
            <Wind className="w-4 h-4" />
            <span className="text-[13px] font-medium uppercase tracking-wider">Air Quality</span>
          </div>
          <span className={`text-[12px] font-bold ${textColor} uppercase tracking-wider`}>{label}</span>
        </div>
        
        <div className="flex items-end gap-2 px-1 mb-4">
          <span className="text-4xl font-semibold text-white leading-none tracking-tight">{aqi}</span>
          <span className="text-white/60 text-sm font-medium mb-1">AQI</span>
        </div>

        <div className="relative h-2.5 w-full bg-white/10 rounded-full overflow-hidden mt-1">
          {/* Color Gradient Background */}
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-green-500 via-yellow-500 to-red-600 opacity-40" />
          {/* Animated Progress indicator */}
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            className={`absolute top-0 left-0 h-full ${color} rounded-full shadow-[0_0_10px_rgba(255,255,255,0.3)]`}
          />
        </div>
        
        <p className="text-white/80 text-[13px] mt-4 font-medium leading-relaxed">
          {healthRec}
        </p>
      </div>

      {pollutants && (
        <div className="grid grid-cols-5 gap-2 mt-5 pt-4 border-t border-white/10">
          <PollutantBox label="PM2.5" value={pollutants.pm25} />
          <PollutantBox label="PM10" value={pollutants.pm10} />
          <PollutantBox label="CO" value={pollutants.co} />
          <PollutantBox label="NO₂" value={pollutants.no2} />
          <PollutantBox label="O₃" value={pollutants.o3} />
        </div>
      )}
    </div>
  );
}

function PollutantBox({ label, value }: { label: string, value?: number }) {
  return (
    <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-black/20">
      <span className="text-[10px] text-white/50 font-medium mb-1">{label}</span>
      <span className="text-[12px] text-white font-semibold">{value !== undefined ? value : '--'}</span>
    </div>
  );
}
