import React from 'react';
import { WeatherAlert } from '../types';
import { AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function WeatherAlerts({ alerts }: { alerts?: WeatherAlert[] }) {
  if (!alerts || alerts.length === 0) return null;

  return (
    <AnimatePresence>
      <div className="flex flex-col gap-3 mt-4">
        {alerts.map((alert, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="overflow-hidden bg-red-600/30 backdrop-blur-xl border border-red-500/50 rounded-2xl p-5 shadow-lg flex flex-col gap-2"
          >
            <div className="flex items-center gap-2 mb-1">
              <span className="text-white font-bold text-[18px] tracking-wide flex items-center gap-2">
                🔴 {alert.headline}
              </span>
            </div>
            {alert.expectedRainfall !== undefined && (
              <p className="text-white/90 text-sm font-medium">
                Expected Rainfall: {alert.expectedRainfall} mm
              </p>
            )}
            {alert.rainProbability !== undefined && (
              <p className="text-white/90 text-sm font-medium">
                Rain Probability: {alert.rainProbability}%
              </p>
            )}
            <p className="text-white/60 text-xs mt-2 font-medium">
              Issued by {alert.issuedBy || 'Local Authority'}
            </p>
          </motion.div>
        ))}
      </div>
    </AnimatePresence>
  );
}
