import React, { useState, useEffect } from 'react';
import { WeatherData, Location } from '../types';
import { getWeatherIcon, getWeatherDescription, formatTemp } from '../utils';
import { Droplets, Wind, Gauge, SunDim, Radio } from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';

interface Props {
  weather: WeatherData;
  location: Location;
  isFahrenheit: boolean;
}

export function CurrentWeather({ weather, location, isFahrenheit }: Props) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col mb-4 pt-10"
    >
      <div className="flex flex-col items-center text-center">
        <h2 className="text-[32px] font-normal tracking-tight text-white drop-shadow-md">
          {location.name}
        </h2>
        <div className="text-[96px] leading-[1] font-extralight text-white drop-shadow-lg tracking-tighter mt-1">
          {formatTemp(weather.current.temperature, isFahrenheit)}°
        </div>
        <p className="text-white/90 text-xl font-medium capitalize mt-2 drop-shadow-md">
          {getWeatherDescription(weather.current.weatherCode)}
        </p>
        <div className="text-white/90 text-lg mt-1 font-medium flex gap-4 drop-shadow-md">
          <span>Feels Like {formatTemp(weather.current.feelsLike, isFahrenheit)}°</span>
        </div>
        <div className="text-white/90 text-lg mt-1 font-medium flex gap-4 drop-shadow-md">
          <span>H:{formatTemp(weather.daily[0]?.tempMax || 0, isFahrenheit)}°</span>
          <span>L:{formatTemp(weather.daily[0]?.tempMin || 0, isFahrenheit)}°</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 w-full mt-10">
        <StatBox icon={Droplets} label="HUMIDITY" value={`${weather.current.humidity}%`} />
        <StatBox icon={Wind} label="WIND" value={`${weather.current.windSpeed} km/h`} subValue={`Gusts ${weather.current.windGusts} km/h`} />
        <StatBox icon={Gauge} label="PRESSURE" value={`${weather.current.pressure} hPa`} />
        <StatBox icon={SunDim} label="UV INDEX" value={weather.daily[0]?.uvIndex?.toString() || 'Low'} />
      </div>
    </motion.div>
  );
}

function StatBox({ icon: Icon, label, value, subValue }: { icon: any, label: string, value: string, subValue?: string }) {
  return (
    <div className="glass-panel p-4 rounded-[24px] flex items-center gap-3 bg-black/20 backdrop-blur-md border border-white/10">
      <div className="bg-white/20 p-2.5 rounded-full shrink-0">
        <Icon className="w-5 h-5 text-white" />
      </div>
      <div className="flex flex-col overflow-hidden">
        <span className="text-[11px] text-white/70 font-semibold tracking-wider truncate">{label}</span>
        <span className="text-[15px] text-white font-medium leading-tight mt-0.5 truncate">{value}</span>
        {subValue && (
          <span className="text-[10px] text-white/50 font-semibold mt-0.5 truncate">{subValue}</span>
        )}
      </div>
    </div>
  );
}
