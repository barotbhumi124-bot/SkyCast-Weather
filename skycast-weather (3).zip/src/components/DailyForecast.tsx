import React from 'react';
import { WeatherData } from '../types';
import { getWeatherIcon, formatTemp } from '../utils';
import { format } from 'date-fns';
import { motion } from 'motion/react';
import { CalendarDays, CloudRain } from 'lucide-react';

export function DailyForecast({ daily, isFahrenheit }: { daily: WeatherData['daily'], isFahrenheit: boolean }) {
  const minOfWeek = Math.min(...daily.map(d => d.tempMin));
  const maxOfWeek = Math.max(...daily.map(d => d.tempMax));

  return (
    <div className="glass-panel rounded-[24px] p-5 h-full mt-4 bg-black/20 backdrop-blur-md border border-white/10">
      <div className="flex items-center gap-2 text-white/60 mb-2 px-1 pb-3 border-b border-white/10">
        <CalendarDays className="w-4 h-4" />
        <span className="text-[12px] font-semibold uppercase tracking-wider">7-Day Forecast</span>
      </div>
      
      <div className="flex flex-col">
        {daily.map((day, idx) => {
          const date = new Date(day.time);
          const Icon = getWeatherIcon(day.weatherCode);

          // Calculate bar position and width
          const range = maxOfWeek - minOfWeek || 1; // Prevent division by zero
          const leftPercent = ((day.tempMin - minOfWeek) / range) * 100;
          const widthPercent = ((day.tempMax - day.tempMin) / range) * 100;

          return (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
              key={day.time}
              className="flex items-center justify-between py-3 border-b border-white/10 last:border-0"
            >
              <div className="w-[80px] text-[16px] font-medium text-white">
                {idx === 0 ? 'Today' : format(date, 'EEEE').slice(0, 3)}
              </div>
              
              <div className="flex flex-col items-center justify-center w-[40px]">
                <Icon className="w-6 h-6 text-white" />
                {day.rainProb > 0 ? (
                  <span className="text-[11px] font-bold text-[#40C4FF] mt-0.5">
                    {day.rainProb}%
                  </span>
                ) : (
                  <span className="text-[11px] font-bold text-transparent mt-0.5">0%</span>
                )}
              </div>

              <div className="flex items-center gap-3 flex-1 ml-4 justify-end text-[16px] font-medium">
                <span className="text-white/50 w-[30px] text-right">{formatTemp(day.tempMin, isFahrenheit)}°</span>
                
                {/* Temperature Range Bar */}
                <div className="relative w-[100px] h-1.5 bg-black/40 rounded-full overflow-hidden shrink-0">
                  <div 
                    className="absolute h-full rounded-full bg-gradient-to-r from-green-400 via-yellow-400 to-red-400"
                    style={{ left: `${leftPercent}%`, width: `${widthPercent}%` }}
                  />
                  {idx === 0 && (
                    <div 
                      className="absolute w-1.5 h-1.5 bg-white rounded-full border border-black/50 top-1/2 -translate-y-1/2 shadow-sm z-10"
                      style={{ left: `calc(${leftPercent}% + 20%)` }} 
                    />
                  )}
                </div>

                <span className="text-white w-[30px] text-right">{formatTemp(day.tempMax, isFahrenheit)}°</span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
