import React from 'react';
import { Thermometer, Info, Bell, Shield, Moon, Radio, User, LogOut, LogIn } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../lib/AuthContext.tsx';

interface Props {
  isFahrenheit: boolean;
  setIsFahrenheit: (v: boolean) => void;
  alertsEnabled: boolean;
  setAlertsEnabled: (v: boolean) => void;
  theme: 'adaptive' | 'dark' | 'light';
  setTheme: (v: 'adaptive' | 'dark' | 'light') => void;
  pushNotificationsEnabled: boolean;
  onTogglePushNotifications: () => void;
}

export function SettingsView({ isFahrenheit, setIsFahrenheit, alertsEnabled, setAlertsEnabled, theme, setTheme, pushNotificationsEnabled, onTogglePushNotifications }: Props) {
  const { user, signIn, signOut } = useAuth();

  const cycleTheme = () => {
    if (theme === 'adaptive') setTheme('dark');
    else if (theme === 'dark') setTheme('light');
    else setTheme('adaptive');
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="flex flex-col gap-6 px-5 pt-12 pb-32 h-full overflow-y-auto no-scrollbar"
    >
      <h2 className="text-3xl font-normal tracking-tight text-white mb-2">Settings</h2>
      
      <div className="glass-panel rounded-[32px] p-2 flex flex-col overflow-hidden">
        {user ? (
          <div className="flex flex-col items-center p-6 border-b border-white/10">
            <img src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`} alt="Profile" className="w-16 h-16 rounded-full shadow-lg border-2 border-white/20 mb-3" />
            <h3 className="text-white font-medium text-lg">{user.displayName}</h3>
            <p className="text-white/60 text-sm mb-4">{user.email}</p>
            <button 
              onClick={signOut}
              className="flex items-center gap-2 px-5 py-2 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded-full font-medium transition-colors text-sm"
            >
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center p-6 border-b border-white/10 text-center">
            <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-3">
              <User className="w-8 h-8 text-white/50" />
            </div>
            <h3 className="text-white font-medium text-lg mb-1">Sign in to WeatherNow</h3>
            <p className="text-white/50 text-sm mb-4">Sync your favorite locations across devices and receive personalized weather alerts.</p>
            <button 
              onClick={signIn}
              className="flex items-center gap-2 px-6 py-2.5 bg-white text-black hover:bg-white/90 rounded-full font-medium transition-colors shadow-lg text-sm"
            >
              <LogIn className="w-4 h-4" /> Sign In with Google
            </button>
          </div>
        )}

        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center gap-4 text-white">
            <div className="p-2 bg-white/10 rounded-full">
              <Thermometer className="w-5 h-5 text-white/90" />
            </div>
            <span className="font-medium text-[15px]">Temperature Unit</span>
          </div>
          <div className="flex bg-black/40 rounded-full p-1 border border-white/10 shadow-inner">
            <button 
              onClick={() => setIsFahrenheit(false)}
              className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-all ${!isFahrenheit ? 'bg-white text-black shadow-md' : 'text-white/60 hover:text-white'}`}
            >
              °C
            </button>
            <button 
              onClick={() => setIsFahrenheit(true)}
              className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-all ${isFahrenheit ? 'bg-white text-black shadow-md' : 'text-white/60 hover:text-white'}`}
            >
              °F
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center gap-4 text-white">
            <div className="p-2 bg-white/10 rounded-full">
              <Bell className="w-5 h-5 text-white/90" />
            </div>
            <span className="font-medium text-[15px]">Weather Alerts</span>
          </div>
          <div 
            onClick={() => setAlertsEnabled(!alertsEnabled)}
            className={`w-12 h-6 rounded-full relative cursor-pointer transition-colors duration-300 ${alertsEnabled ? 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.4)]' : 'bg-white/20'}`}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-transform duration-300 ${alertsEnabled ? 'translate-x-7' : 'translate-x-1'}`} />
          </div>
        </div>

        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center gap-4 text-white">
            <div className="p-2 bg-white/10 rounded-full">
              <Radio className="w-5 h-5 text-white/90" />
            </div>
            <div className="flex flex-col">
              <span className="font-medium text-[15px]">Push Notifications</span>
              <span className="text-[11px] text-white/50">Daily morning summary & extreme alerts</span>
            </div>
          </div>
          <div 
            onClick={onTogglePushNotifications}
            className={`w-12 h-6 rounded-full relative cursor-pointer transition-colors duration-300 ${pushNotificationsEnabled ? 'bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.4)]' : 'bg-white/20'}`}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-md transition-transform duration-300 ${pushNotificationsEnabled ? 'translate-x-7' : 'translate-x-1'}`} />
          </div>
        </div>
        
        <div className="flex items-center justify-between p-4 border-b border-white/10 cursor-pointer hover:bg-white/5 transition-colors" onClick={cycleTheme}>
          <div className="flex items-center gap-4 text-white">
            <div className="p-2 bg-white/10 rounded-full">
              <Moon className="w-5 h-5 text-white/90" />
            </div>
            <span className="font-medium text-[15px]">Theme</span>
          </div>
          <span className="text-white/60 text-[13px] font-medium px-2 capitalize">{theme}</span>
        </div>

        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4 text-white">
            <div className="p-2 bg-white/10 rounded-full">
              <Shield className="w-5 h-5 text-white/90" />
            </div>
            <span className="font-medium text-[15px]">Privacy & Terms</span>
          </div>
        </div>
      </div>
      
      <div className="glass-panel rounded-[32px] p-6 flex flex-col items-center justify-center text-center mt-2 border border-white/10">
        <Info className="w-8 h-8 text-white/40 mb-3" />
        <h3 className="text-white font-medium text-[15px] mb-1">WeatherNow Pro</h3>
        <p className="text-white/50 text-[13px]">Version 2.0.1 (Build 492)</p>
        <div className="mt-4 px-4 py-1.5 bg-white/10 rounded-full text-[11px] font-semibold text-white/60 tracking-wider uppercase">
          Up to date
        </div>
      </div>
    </motion.div>
  );
}
