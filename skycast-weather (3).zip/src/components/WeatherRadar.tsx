import React, { useState, useEffect } from 'react';
import { Map, Play, Pause, Thermometer, Wind, CloudRain } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Location, WeatherData } from '../types';

interface Props {
  location: Location;
  hourly: WeatherData['hourly'];
}

type RadarMode = 'precipitation' | 'temperature' | 'wind';

export function WeatherRadar({ location, hourly }: Props) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [frame, setFrame] = useState(0);
  const [mode, setMode] = useState<RadarMode>('precipitation');

  // Next 4 hours of data
  const dataFrames = hourly.slice(0, 4);
  
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setFrame(f => (f + 1) % dataFrames.length);
    }, 1500);
    return () => clearInterval(interval);
  }, [isPlaying, dataFrames.length]);

  const currentData = dataFrames[frame] || dataFrames[0];
  
  const getBlobProps = () => {
    switch (mode) {
      case 'precipitation': {
        const prob = currentData.rainProb || 0;
        let color = 'rgba(255, 255, 255, 0.05)';
        if (prob > 70) color = 'rgba(239, 68, 68, 0.6)';
        else if (prob > 40) color = 'rgba(234, 179, 8, 0.5)';
        else if (prob > 10) color = 'rgba(59, 130, 246, 0.4)';
        
        return {
          color,
          scale: 1 + (prob / 100) * 0.5,
          secondaryColor: prob > 20 ? 'rgba(59, 130, 246, 0.4)' : 'transparent',
          filter: 'url(#radar-goo)',
        };
      }
      case 'temperature': {
        const temp = currentData.temperature || 0;
        let color = 'rgba(59, 130, 246, 0.6)'; // Blue
        if (temp > 35) color = 'rgba(220, 38, 38, 0.7)'; // Red
        else if (temp > 25) color = 'rgba(249, 115, 22, 0.6)'; // Orange
        else if (temp > 15) color = 'rgba(250, 204, 21, 0.5)'; // Yellow
        else if (temp > 5) color = 'rgba(56, 189, 248, 0.5)'; // Sky
        
        // Size changes slightly based on absolute temp deviation from 15
        const scale = 1 + Math.abs(temp - 15) * 0.02;
        return {
          color,
          scale,
          secondaryColor: color,
          filter: 'url(#heatmap-goo)',
        };
      }
      case 'wind': {
        const speed = currentData.windSpeed || 0;
        let color = 'rgba(255, 255, 255, 0.2)';
        if (speed > 50) color = 'rgba(147, 51, 234, 0.6)'; // Purple
        else if (speed > 30) color = 'rgba(236, 72, 153, 0.5)'; // Pink
        else if (speed > 15) color = 'rgba(168, 85, 247, 0.4)'; // Light purple
        
        return {
          color,
          scale: 1 + (speed / 100) * 0.8,
          secondaryColor: 'rgba(255, 255, 255, 0.1)',
          filter: 'url(#wind-turbulence)',
        };
      }
    }
  };

  const currentProps = getBlobProps();

  return (
    <div className="glass-panel rounded-[32px] p-5 flex flex-col h-full min-h-[300px] overflow-hidden relative">
      <div className="flex flex-col gap-3 mb-3 z-10 relative">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2 text-white/70">
            <Map className="w-4 h-4" />
            <span className="text-[13px] font-medium uppercase tracking-wider">Live Radar</span>
          </div>
          <button 
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-1.5 bg-white/10 hover:bg-white/20 rounded-full transition-colors text-white"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
        </div>

        <div className="flex bg-black/40 rounded-lg p-1 border border-white/5">
          <button 
            onClick={() => setMode('precipitation')} 
            className={`flex-1 py-1.5 flex items-center justify-center gap-1.5 text-[11px] uppercase tracking-wider font-bold rounded-md transition-colors ${mode === 'precipitation' ? 'bg-blue-500/80 text-white shadow-[0_0_10px_rgba(59,130,246,0.3)]' : 'text-white/50 hover:bg-white/5'}`}
          >
            <CloudRain className="w-3 h-3" /> Rain
          </button>
          <button 
            onClick={() => setMode('temperature')} 
            className={`flex-1 py-1.5 flex items-center justify-center gap-1.5 text-[11px] uppercase tracking-wider font-bold rounded-md transition-colors ${mode === 'temperature' ? 'bg-orange-500/80 text-white shadow-[0_0_10px_rgba(249,115,22,0.3)]' : 'text-white/50 hover:bg-white/5'}`}
          >
            <Thermometer className="w-3 h-3" /> Temp
          </button>
          <button 
            onClick={() => setMode('wind')} 
            className={`flex-1 py-1.5 flex items-center justify-center gap-1.5 text-[11px] uppercase tracking-wider font-bold rounded-md transition-colors ${mode === 'wind' ? 'bg-purple-500/80 text-white shadow-[0_0_10px_rgba(168,85,247,0.3)]' : 'text-white/50 hover:bg-white/5'}`}
          >
            <Wind className="w-3 h-3" /> Wind
          </button>
        </div>
      </div>

      <div className="flex-1 relative rounded-2xl overflow-hidden bg-[#1e293b]/50 border border-white/10 mt-1">
        {/* SVG Filters Definition */}
        <svg style={{ position: 'absolute', width: 0, height: 0 }} aria-hidden="true">
          <defs>
            <filter id="radar-goo">
              <feGaussianBlur in="SourceGraphic" stdDeviation="10" result="blur" />
              <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -7" result="goo" />
            </filter>
            <filter id="heatmap-goo">
              <feGaussianBlur in="SourceGraphic" stdDeviation="20" result="blur" />
              <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 25 -12" result="goo" />
            </filter>
            <filter id="wind-turbulence">
              <feTurbulence type="fractalNoise" baseFrequency="0.01 0.1" numOctaves="3" result="noise">
                {isPlaying && (
                  <animate attributeName="baseFrequency" values="0.01 0.1; 0.05 0.5; 0.01 0.1" dur="10s" repeatCount="indefinite" />
                )}
              </feTurbulence>
              <feDisplacementMap in="SourceGraphic" in2="noise" scale="30" xChannelSelector="R" yChannelSelector="G" />
              <feGaussianBlur stdDeviation="5" />
            </filter>
          </defs>
        </svg>

        {/* Map Grid Background */}
        <div className="absolute inset-0 z-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at center, white 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
        
        {/* City Marker */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center">
          <div className="w-3 h-3 bg-white rounded-full shadow-[0_0_10px_white]"></div>
          <span className="text-[10px] font-bold text-white mt-1 drop-shadow-md bg-black/30 px-1.5 py-0.5 rounded">{location.name}</span>
        </div>

        {/* Animated Radar Blobs Container with dynamic filter */}
        <div 
          className="absolute inset-0 z-10 flex items-center justify-center pointer-events-none transition-all duration-700"
          style={{ filter: currentProps.filter }}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={`${mode}-${frame}`}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: currentProps.scale }}
              exit={{ opacity: 0, scale: 1.2 }}
              transition={{ duration: 1.2, ease: "easeInOut" }}
              className="absolute rounded-full"
              style={{
                width: '180px',
                height: '140px',
                backgroundColor: currentProps.color,
                transformOrigin: 'center',
              }}
            />
          </AnimatePresence>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={`secondary-${mode}-${frame}`}
              initial={{ opacity: 0, scale: 0.9, x: 20, y: -20 }}
              animate={{ opacity: 1, scale: currentProps.scale * 0.8, x: 10, y: -10 }}
              exit={{ opacity: 0, scale: 1.1, x: 0, y: 0 }}
              transition={{ duration: 1.4, ease: "easeInOut", delay: 0.2 }}
              className="absolute rounded-full"
              style={{
                width: '120px',
                height: '100px',
                backgroundColor: currentProps.secondaryColor,
              }}
            />
          </AnimatePresence>
        </div>
        
        {/* Radar Sweep Line */}
        {isPlaying && mode === 'precipitation' && (
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            className="absolute top-1/2 left-1/2 w-[150%] h-[150%] z-30 pointer-events-none"
            style={{ transformOrigin: '0 0' }}
          >
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-green-400/50 to-transparent shadow-[0_0_8px_rgba(74,222,128,0.5)]"></div>
          </motion.div>
        )}

        {/* Timeline indicator */}
        <div className="absolute bottom-2 left-2 right-2 flex justify-between z-40">
          {dataFrames.map((_, i) => (
            <div key={i} className={`h-1.5 flex-1 mx-0.5 rounded-full transition-all duration-300 ${i === frame ? 'bg-white shadow-[0_0_5px_white]' : 'bg-white/20'}`} />
          ))}
        </div>
        <div className="absolute top-2 left-2 z-40 bg-black/40 px-2 py-0.5 rounded-full border border-white/10 backdrop-blur-md">
          <span className="text-[10px] text-white/90 font-medium font-mono">+{frame}H FORECAST</span>
        </div>
      </div>
    </div>
  );
}

