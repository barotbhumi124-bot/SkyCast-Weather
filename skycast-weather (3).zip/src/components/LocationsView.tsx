import React from 'react';
import { SearchBar } from './SearchBar';
import { Location } from '../types';
import { Heart, MapPin, Trash2, Map as MapIcon } from 'lucide-react';
import { motion } from 'motion/react';

interface Props {
  favorites: Location[];
  onSelect: (loc: Location) => void;
  onGeolocate: () => void;
  isLocating: boolean;
  onRemoveFavorite: (id: number) => void;
  currentLocationId: number;
}

export function LocationsView({ favorites, onSelect, onGeolocate, isLocating, onRemoveFavorite, currentLocationId }: Props) {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="flex flex-col gap-6 px-5 pt-12 pb-32 h-full"
    >
      <div className="flex items-center gap-3 mb-2">
        <MapIcon className="w-8 h-8 text-white/90" />
        <h2 className="text-3xl font-normal tracking-tight text-white">Locations</h2>
      </div>
      
      <div className="relative z-50">
        <SearchBar onSelect={onSelect} onGeolocate={onGeolocate} isLocating={isLocating} />
      </div>

      <div className="flex-1 flex flex-col gap-3 overflow-y-auto no-scrollbar pb-10">
        <h3 className="text-white/60 text-[11px] font-bold uppercase tracking-widest mt-2 px-2">Saved Cities</h3>
        
        {favorites.length === 0 ? (
          <div className="glass-panel rounded-[32px] flex flex-col items-center justify-center py-12 px-6 text-center border-dashed border-white/20">
            <MapPin className="w-10 h-10 text-white/30 mb-4" />
            <p className="text-white/80 font-medium text-[15px] mb-2">No locations saved</p>
            <p className="text-white/50 text-[13px]">Search for a city above to add it to your favorites.</p>
          </div>
        ) : (
          favorites.map((loc) => {
            const isActive = currentLocationId === loc.id;
            return (
              <div 
                key={loc.id} 
                className={`glass-panel rounded-3xl p-4 flex items-center justify-between group transition-all cursor-pointer ${isActive ? 'bg-white/20 border border-white/30 shadow-[0_0_20px_rgba(255,255,255,0.15)] scale-[1.02]' : 'hover:bg-white/10 border border-transparent'}`}
                onClick={() => onSelect(loc)}
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2.5 rounded-full shadow-inner ${isActive ? 'bg-white text-black' : 'bg-white/10 text-white'}`}>
                    {loc.name === "Current Location" ? <MapPin className="w-5 h-5" /> : <Heart className={`w-5 h-5 ${isActive ? 'fill-black' : 'fill-white'}`} />}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-white font-medium text-[17px]">{loc.name}</span>
                    <span className="text-white/60 text-[13px]">{loc.admin1 ? `${loc.admin1}, ` : ''}{loc.country}</span>
                  </div>
                </div>
                
                <button 
                  onClick={(e) => { e.stopPropagation(); onRemoveFavorite(loc.id); }}
                  className={`p-2.5 rounded-full transition-colors ${isActive ? 'text-white/50 hover:text-white hover:bg-white/20' : 'text-white/30 hover:text-red-400 hover:bg-red-400/20 opacity-0 group-hover:opacity-100'}`}
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            );
          })
        )}
      </div>
    </motion.div>
  );
}
