import React, { useEffect, useState } from 'react';
import { fetchWeather } from '../api';
import { WeatherData } from '../types';
import { getWeatherIcon, formatTemp } from '../utils';
import { MapPin } from 'lucide-react';
import { motion } from 'motion/react';

const GUJARAT_CITIES = [
  { name: 'Ahmedabad', lat: 23.0225, lon: 72.5714 },
  { name: 'Vadodara', lat: 22.3072, lon: 73.1812 },
  { name: 'Surat', lat: 21.1702, lon: 72.8311 },
  { name: 'Rajkot', lat: 22.3039, lon: 70.8022 },
  { name: 'Jamnagar', lat: 22.4707, lon: 70.0577 },
  { name: 'Dwarka', lat: 22.2442, lon: 68.9685 },
  { name: 'Bhavnagar', lat: 21.7645, lon: 72.1519 },
  { name: 'Junagadh', lat: 21.5222, lon: 70.4579 },
];

export function GujaratWeather({ isFahrenheit }: { isFahrenheit: boolean }) {
  const [data, setData] = useState<{ city: string; weather: WeatherData | null }[]>(
    GUJARAT_CITIES.map(c => ({ city: c.name, weather: null }))
  );
  
  useEffect(() => {
    let mounted = true;
    
    async function loadData() {
      const results = await Promise.all(
        GUJARAT_CITIES.map(async (c) => {
          try {
            const weather = await fetchWeather(c.lat, c.lon);
            return { city: c.name, weather };
          } catch (e) {
            return { city: c.name, weather: null };
          }
        })
      );
      if (mounted) {
        setData(results);
      }
    }
    
    loadData();
    
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div className="glass-panel rounded-[24px] p-5 h-full mt-4 bg-black/20 backdrop-blur-md border border-white/10">
      <div className="flex items-center gap-2 text-white/60 mb-3 px-1 border-b border-white/10 pb-3">
        <MapPin className="w-4 h-4" />
        <span className="text-[12px] font-semibold uppercase tracking-wider">Gujarat Weather</span>
      </div>
      
      <div className="flex overflow-x-auto gap-4 pb-2 snap-x no-scrollbar">
        {data.map((item, idx) => {
          if (!item.weather) {
            return (
              <div key={item.city} className="min-w-[120px] h-[140px] shrink-0 snap-start bg-white/5 rounded-2xl animate-pulse" />
            );
          }
          
          const Icon = getWeatherIcon(item.weather.current.weatherCode);
          const hasAlert = item.weather.alerts && item.weather.alerts.length > 0;

          return (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
              key={item.city}
              className="flex flex-col min-w-[120px] shrink-0 snap-start bg-black/30 rounded-2xl p-4 border border-white/10 relative overflow-hidden"
            >
              <span className="text-[14px] font-semibold text-white mb-2 truncate">
                {item.city}
              </span>
              
              <div className="flex items-center justify-between mb-2">
                <span className="font-light text-[24px] text-white">
                  {formatTemp(item.weather.current.temperature, isFahrenheit)}°
                </span>
                <Icon className="w-8 h-8 text-white drop-shadow-sm" />
              </div>
              
              <div className="flex items-center justify-between mt-auto">
                {item.weather.current.rainProb ? (
                  <span className="text-[12px] font-bold text-[#40C4FF]">{item.weather.current.rainProb}% Rain</span>
                ) : (
                  <span className="text-[12px] font-bold text-transparent">0%</span>
                )}
              </div>
              
              {hasAlert && (
                <div className="absolute top-0 left-0 w-full h-1 bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.8)]" />
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
