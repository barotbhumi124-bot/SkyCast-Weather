import React, { useState, useEffect } from 'react';
import { Sparkles, TerminalSquare } from 'lucide-react';
import { WeatherData, Location } from '../types';
import Markdown from 'react-markdown';

interface Props {
  weather: WeatherData;
  location: Location;
}

export function AiInsights({ weather, location }: Props) {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    async function fetchInsights() {
      setLoading(true);
      setError(false);
      try {
        const response = await fetch('/api/insights', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ weatherData: weather, location }),
        });
        
        
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        setInsight(data.insight);
      } catch (err) {
        console.error("Failed to fetch insights:", err);
        setError(true);
      } finally {
        setLoading(false);
      }
    }

    fetchInsights();
  }, [weather.current.temperature, weather.current.weatherCode]);

  return (
    <div className="glass-panel rounded-[32px] p-5 h-full relative overflow-hidden group">
      {/* Glitch/Cyberpunk styling elements */}
      <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/20 blur-2xl rounded-full mix-blend-screen pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-indigo-500/20 blur-2xl rounded-full mix-blend-screen pointer-events-none"></div>
      
      <div className="flex items-center gap-2 text-white/70 mb-3 px-1 relative z-10">
        <Sparkles className="w-4 h-4 text-blue-400" />
        <span className="text-[13px] font-medium uppercase tracking-widest text-blue-300">AI Forecast Insights</span>
      </div>

      <div className="bg-black/40 rounded-2xl p-4 border border-white/10 shadow-[0_0_15px_rgba(59,130,246,0.1)] relative z-10 min-h-[120px] flex items-center">
        <div className="absolute -left-px top-4 bottom-4 w-0.5 bg-gradient-to-b from-blue-400 via-indigo-500 to-transparent shadow-[0_0_8px_rgba(59,130,246,0.6)]"></div>
        
        {loading ? (
          <div className="w-full flex flex-col items-center justify-center gap-3 py-2">
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-4 bg-blue-400 animate-pulse"></div>
              <div className="w-1.5 h-6 bg-indigo-500 animate-pulse" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-1.5 h-4 bg-blue-400 animate-pulse" style={{ animationDelay: '0.2s' }}></div>
            </div>
            <span className="text-[10px] uppercase tracking-widest text-white/50 font-sans">Analyzing atmospheric data...</span>
          </div>
        ) : error ? (
          <div className="w-full flex items-center justify-center gap-2 text-white/50 py-2">
            <TerminalSquare className="w-4 h-4" />
            <span className="text-[11px] font-mono">Neural link severed. Retrying later.</span>
          </div>
        ) : (
          <div className="text-white/90 text-[14px] leading-relaxed font-mono tracking-tight drop-shadow-sm markdown-content">
            <Markdown>{insight ? insight : "Initializing neural projection..."}</Markdown>
          </div>
        )}
      </div>
      
      {/* Decorative tech lines */}
      <div className="absolute right-4 bottom-3 flex gap-1 pointer-events-none">
        <div className="w-4 h-[1px] bg-white/20"></div>
        <div className="w-2 h-[1px] bg-white/40"></div>
        <div className="w-1 h-[1px] bg-blue-400/60"></div>
      </div>
    </div>
  );
}
