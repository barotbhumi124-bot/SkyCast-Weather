import React from 'react';
import { WeatherData } from '../types';
import { getWeatherIcon, formatTemp } from '../utils';
import { format } from 'date-fns';
import { Clock } from 'lucide-react';
import { motion } from 'motion/react';

export function HourlyForecast({ hourly, isFahrenheit }: { hourly: WeatherData['hourly'], isFahrenheit: boolean }) {
  return (
    <div className="glass-panel rounded-[24px] p-4 mt-4 bg-black/20 backdrop-blur-md border border-white/10">
      <div className="flex items-center gap-2 text-white/60 mb-3 px-1 border-b border-white/10 pb-3">
        <Clock className="w-4 h-4" />
        <span className="text-[12px] font-semibold uppercase tracking-wider">Hourly Forecast</span>
      </div>
      
      <div className="flex overflow-x-auto gap-4 pb-2 snap-x no-scrollbar">
        {hourly.map((hour, idx) => {
          const date = new Date(hour.time);
          const isNow = idx === 0;
          const Icon = getWeatherIcon(hour.weatherCode);

          return (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              key={hour.time}
              className="flex flex-col items-center justify-between min-w-[56px] shrink-0 snap-start"
            >
              <span className="text-[14px] font-medium text-white mb-2">
                {isNow ? 'Now' : format(date, 'h a')}
              </span>
              <Icon className="w-6 h-6 mb-1 text-white shadow-sm" />
              {hour.rainProb > 0 ? (
                <span className="text-[11px] font-bold text-[#40C4FF] mb-1">{hour.rainProb}%</span>
              ) : (
                <span className="text-[11px] font-bold text-transparent mb-1">0%</span>
              )}
              <span className="font-medium text-[16px] text-white mb-1">
                {formatTemp(hour.temperature, isFahrenheit)}°
              </span>
              {hour.precipitation ? (
                <span className="text-[10px] text-[#40C4FF]">{hour.precipitation}mm</span>
              ) : (
                <span className="text-[10px] text-transparent">0mm</span>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
