import React, { useState, useEffect } from 'react';
import { Database, TerminalSquare } from 'lucide-react';
import Markdown from 'react-markdown';

export function WeatherFact() {
  const [fact, setFact] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchFact() {
      try {
        const response = await fetch('/api/weather-fact');
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        setFact(data.fact);
      } catch (err) {
        console.error("Failed to fetch fact:", err);
        setFact("Offline. The highest temperature ever recorded on Earth was 134°F (56.7°C) at Furnace Creek Ranch, Death Valley, California.");
      } finally {
        setLoading(false);
      }
    }

    fetchFact();
  }, []);

  return (
    <div className="glass-panel rounded-[32px] p-5 h-full relative overflow-hidden group">
      {/* Glitch/Cyberpunk styling elements */}
      <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/20 blur-2xl rounded-full mix-blend-screen pointer-events-none"></div>
      
      <div className="flex items-center justify-between mb-3 px-1 relative z-10">
        <div className="flex items-center gap-2 text-white/70">
          <Database className="w-4 h-4 text-blue-400" />
          <span className="text-[13px] font-medium uppercase tracking-widest text-blue-300">Daily Datapad</span>
        </div>
      </div>

      <div className="bg-black/40 rounded-2xl p-4 border border-blue-500/20 shadow-[0_0_15px_rgba(59,130,246,0.1)] relative z-10 min-h-[100px] flex items-center">
        <div className="absolute -left-px top-4 bottom-4 w-0.5 bg-gradient-to-b from-blue-400 via-sky-500 to-transparent shadow-[0_0_8px_rgba(59,130,246,0.6)]"></div>
        
        {loading ? (
          <div className="w-full flex items-center gap-3 py-2">
            <TerminalSquare className="w-4 h-4 text-blue-400 animate-pulse" />
            <span className="text-[10px] uppercase tracking-widest text-white/50 font-mono">Accessing Archives...</span>
          </div>
        ) : (
          <div className="text-white/90 text-[13px] leading-relaxed font-mono tracking-tight drop-shadow-sm w-full markdown-content">
            <Markdown>{fact || ""}</Markdown>
          </div>
        )}
      </div>
    </div>
  );
}
