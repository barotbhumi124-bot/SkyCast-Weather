import React from 'react';
import { Moon } from 'lucide-react';
import { motion } from 'motion/react';

function getMoonData() {
  const date = new Date();
  let year = date.getFullYear();
  let month = date.getMonth() + 1;
  let day = date.getDate();

  if (month < 3) {
    year--;
    month += 12;
  }
  month++;
  
  const c = 365.25 * year;
  const e = 30.6 * month;
  let jd = c + e + day - 694039.09; // total days elapsed
  jd /= 29.5305882; // divide by the moon cycle
  const b = Math.floor(jd); // integer part
  jd -= b; // fractional part from 0 to 1
  
  const phaseIndex = Math.round(jd * 8) % 8;
  const illumination = Math.round((0.5 - Math.abs(jd - 0.5)) * 2 * 100);
  
  const phases = [
    'New Moon',
    'Waxing Crescent',
    'First Quarter',
    'Waxing Gibbous',
    'Full Moon',
    'Waning Gibbous',
    'Third Quarter',
    'Waning Crescent'
  ];

  return { phaseName: phases[phaseIndex], illumination, jd };
}

// Custom icons based on phase for the UI
function MoonIcon({ jd, className }: { jd: number; className?: string }) {
  // A simple representation using SVG based on illumination
  return (
    <svg viewBox="0 0 100 100" className={className}>
      <circle cx="50" cy="50" r="40" fill="#333" />
      <path
        d={`M 50 10 A 40 40 0 0 ${jd > 0.5 ? 0 : 1} 50 90 A ${Math.abs(0.5 - jd) * 80} 40 0 0 ${jd < 0.25 || jd > 0.75 ? 1 : 0} 50 10`}
        fill="#fcd34d"
      />
    </svg>
  );
}

export function MoonPhase() {
  const { phaseName, illumination, jd } = getMoonData();

  return (
    <div className="glass-panel rounded-[32px] p-5 h-full flex flex-col">
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="flex items-center gap-2 text-white/70">
          <Moon className="w-4 h-4" />
          <span className="text-[13px] font-medium uppercase tracking-wider">Moon Phase</span>
        </div>
      </div>
      
      <div className="flex-1 flex flex-col justify-center items-center text-center">
        <div className="w-16 h-16 relative shadow-[0_0_15px_rgba(252,211,77,0.15)] rounded-full mb-3">
          <MoonIcon jd={jd} className="w-full h-full drop-shadow-[0_0_8px_rgba(252,211,77,0.4)]" />
        </div>
        
        <div className="text-[17px] font-medium text-white tracking-tight leading-tight">{phaseName}</div>
        <div className="text-white/60 text-[11px] font-semibold uppercase tracking-wider mt-1">{illumination}% Illum</div>
      </div>
    </div>
  );
}
