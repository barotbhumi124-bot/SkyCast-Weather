import React from 'react';
import { Sunrise, Sunset } from 'lucide-react';
import { format } from 'date-fns';

interface Props {
  sunrise: string;
  sunset: string;
}

export function SunTimes({ sunrise, sunset }: Props) {
  const formatTime = (timeString: string) => {
    if (!timeString) return '--:--';
    return format(new Date(timeString), 'h:mm a');
  };

  return (
    <div className="glass-panel rounded-[32px] p-5 h-full flex flex-col">
      <div className="flex items-center gap-2 text-white/70 mb-4 px-1">
        <Sunrise className="w-4 h-4" />
        <span className="text-[13px] font-medium uppercase tracking-wider">Sun Times</span>
      </div>
      
      <div className="flex-1 flex flex-col justify-center gap-4 px-1">
        <div className="flex items-center gap-3">
          <Sunrise className="w-8 h-8 text-amber-400" />
          <div className="flex flex-col">
            <span className="text-white font-medium text-[17px]">{formatTime(sunrise)}</span>
            <span className="text-white/60 text-[11px] font-semibold uppercase tracking-wider">Sunrise</span>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <Sunset className="w-8 h-8 text-orange-400" />
          <div className="flex flex-col">
            <span className="text-white font-medium text-[17px]">{formatTime(sunset)}</span>
            <span className="text-white/60 text-[11px] font-semibold uppercase tracking-wider">Sunset</span>
          </div>
        </div>
      </div>
    </div>
  );
}
