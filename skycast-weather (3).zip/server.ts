import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import { requireAuth, AuthRequest } from './src/middleware/auth.ts';
import { db } from './src/db/index.ts';
import { favorites } from './src/db/schema.ts';
import { eq, and } from 'drizzle-orm';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post("/api/insights", async (req, res) => {
    const { weatherData, location } = req.body;
    try {
      const ai = new GoogleGenAI({ 
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `You are an AI weather assistant. Provide a short, premium, modern summary (2-3 sentences max) of the weather today in ${location.name} and suggest a suitable activity or venue nearby using Maps tools based on this data. Make it sound helpful and professional.
        
        Weather Data:
        Temperature: ${weatherData.current.temperature}° (Feels like ${weatherData.current.feelsLike}°)
        Condition: ${weatherData.current.weatherCode}
        Wind: ${weatherData.current.windSpeed} km/h (Gusts: ${weatherData.current.windGusts} km/h)
        UV Index: ${weatherData.daily[0]?.uvIndex || 'Low'}
        Rain Probability: ${weatherData.daily[0]?.rainProb || 0}%`,
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: {
                latitude: location.lat,
                longitude: location.lon
              }
            }
          }
        }
      });

      res.json({ insight: response.text });
    } catch (error) {
      // API quota or other error - use fallback response
      res.json({ 
        insight: `The current temperature is ${weatherData.current.temperature}°. Conditions look stable. Consider planning your activities accordingly today.` 
      });
    }
  });

  app.get("/api/weather-fact", async (req, res) => {
    try {
      const ai = new GoogleGenAI({ 
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Provide a single, fascinating, true meteorological or weather-related fact. Keep it under 2 sentences.`,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      res.json({ fact: response.text });
    } catch (error) {
      // API quota or other error - use fallback response
      res.json({ 
        fact: "Did you know a single bolt of lightning contains enough energy to toast 100,000 slices of bread?" 
      });
    }
  });

  // Database API Routes
  app.get("/api/favorites", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userUid = req.user?.uid;
      if (!userUid) return res.status(401).json({ error: "Unauthorized" });

      const result = await db.select().from(favorites).where(eq(favorites.userId, userUid));
      res.json(result);
    } catch (error) {
      console.error("Database query failed:", error);
      res.status(500).json({ error: "Failed to fetch favorites" });
    }
  });

  app.post("/api/favorites", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userUid = req.user?.uid;
      if (!userUid) return res.status(401).json({ error: "Unauthorized" });

      const { locationName, latitude, longitude, country, admin1 } = req.body;
      
      const result = await db.insert(favorites).values({
        userId: userUid,
        locationName,
        latitude,
        longitude,
        country,
        admin1
      }).returning();
      
      res.json(result[0]);
    } catch (error) {
      console.error("Database query failed:", error);
      res.status(500).json({ error: "Failed to add favorite" });
    }
  });

  app.delete("/api/favorites/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      const userUid = req.user?.uid;
      if (!userUid) return res.status(401).json({ error: "Unauthorized" });

      const { id } = req.params;
      await db.delete(favorites).where(and(eq(favorites.id, parseInt(id)), eq(favorites.userId, userUid)));
      
      res.json({ success: true });
    } catch (error) {
      console.error("Database query failed:", error);
      res.status(500).json({ error: "Failed to remove favorite" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
